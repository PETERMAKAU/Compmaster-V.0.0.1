/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compmaster;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;

/**
 *
 * @author peter
 */
class Compmaster_Loop2 implements Runnable{
     static Connection conn = null;
     static ResultSet rs = null; 
     static PreparedStatement pst = null;
    @Override
    public void run(){
      conn = mysqlconnect.ConnectDb();
         start_timer(1);

    }

    private void start_timer(int seconds){
    timerx = new java.util.Timer();   
    timerx.schedule(new Compmaster_Loop2.RemindTask(), seconds * 500, 5000);
    }
    static void stop_timer(){
     //timer = new java.util.Timer();  
      //  lbl_per.setText("Copleted");
    timerx.cancel();
    }

    private void update_table() {
                    
      //here
    }
    class RemindTask extends TimerTask {
    public void run() {
    
      timR();
     
    }
  }
     
     public void timR(){
   
        try{
            update_table();
         //   System 
       // update_progress();
        //JOptionPane.showMessageDialog(null, "Update Jtable");
        }
     catch (Exception e){
     JOptionPane.showMessageDialog(null, e);
     }
  
  }
     
   static Timer timerx;
    }