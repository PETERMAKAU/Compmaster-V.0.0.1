/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compmaster;

import static compmaster.Compmaster_Loop.data_chabdata_count;
import static compmaster.Compmaster_Loop.data_used_only_indices;
import static compmaster.Compmaster_Loop.size_store;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;

/**
 *
 * @author peter
 */
class Compmaster_Loop2 implements Runnable{
     static Connection conn = null;
     static ResultSet rs = null; 
     static PreparedStatement pst = null;
      static ArrayList<String> size_store_1;
     static ArrayList<String> data_chabdata_count_1;
      static  ArrayList<String> data_used_only_indices_1;
     int first_loop_com=0;
     
    @Override
    public void run(){
        
        data_used_only_indices_1=new ArrayList<String>(); 
     size_store_1= new ArrayList<String>();     
     data_chabdata_count_1= new ArrayList<String>();
    //  conn = mysqlconnect.ConnectDb();
       //  start_timer(1);

    }

   
    
     public void set_complete_part1(){
     data_used_only_indices_1=data_used_only_indices;
     size_store_1=size_store;
     data_chabdata_count_1=data_chabdata_count;
     first_loop_com=1;
     
     
      
    }
    
    }