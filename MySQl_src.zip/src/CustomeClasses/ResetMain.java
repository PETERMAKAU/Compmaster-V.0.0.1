/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CustomeClasses;

import java.util.Scanner;

/**
 *
 * @author peter
 */
public class ResetMain {
    static boolean finished =false;
   public static void main(String[] args) {
    while (true) {
  System.out.println("Please enter a math value");

  // The rest of your code.

  if (finished)
    break;
}
} 
}
